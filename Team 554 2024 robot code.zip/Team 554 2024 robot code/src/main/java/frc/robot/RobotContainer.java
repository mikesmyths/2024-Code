
package frc.robot;

import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.commands.PathPlannerAuto;

import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import frc.robot.Constants.XBOXconstants;
import frc.robot.commands.SetTargetPosition;
//import frc.robot.commands.SetWheelsToZero;
import frc.robot.commands.AutoGyroPreset;
import frc.robot.commands.GyroReset;
import frc.robot.commands.JoystickMultiplier;
import frc.robot.commands.PickupStartAuto;
import frc.robot.commands.ShooterStart;
import frc.robot.commands.ShooterStartAuto;
import frc.robot.commands.ShooterStartAutoNoArmMove;
import frc.robot.commands.ShooterStop;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;
import edu.wpi.first.wpilibj2.command.button.Trigger;

//@SuppressWarnings("unused")

public class RobotContainer {

  //------------------------------------O-B-J-E-C-T-S-----------------------------------//

  XboxController m_driverController = new XboxController(0);
  XboxController m_operatorController = new XboxController(1);

  
  SendableChooser<Command> autochooser = new SendableChooser<>();
  //SendableChooser<Integer> ledchooser = new SendableChooser<>();
  //SendableChooser<Boolean> armmodechooser = new SendableChooser<>();
	

  public RobotContainer(){

    NamedCommands.registerCommand("AutoShooterStart",new  ShooterStartAuto());
    NamedCommands.registerCommand("AutoShooterStartNoArmMove",new  ShooterStartAutoNoArmMove());
    NamedCommands.registerCommand("AutoMoveArmToAmp", new SetTargetPosition(RobotMap.Amp_Index));
    NamedCommands.registerCommand("AutoMoveArmToSpeakerNear", new SetTargetPosition(RobotMap.AutoSpeakerNear_Index));
    NamedCommands.registerCommand("AutoMoveArmToSpeakerFar", new SetTargetPosition(RobotMap.SpeakerFar_Index));
    NamedCommands.registerCommand("AutoPickupStart", new PickupStartAuto());
    NamedCommands.registerCommand("AutoGyroOffset60", new AutoGyroPreset(60.));
    NamedCommands.registerCommand("AutoGyroOffsetMinus60", new AutoGyroPreset(-60.));


    autochooser.addOption("DO NOTHING",null);
    autochooser.setDefaultOption("Auto01- (MIDDLE, SPEAKER, AMP)",new PathPlannerAuto("Auto01"));
    autochooser.addOption("Auto02-Near Openside + 1", new PathPlannerAuto("Auto02"));
    autochooser.addOption("Auto03-Near Ampside + 1",new PathPlannerAuto("Auto03"));
    autochooser.addOption("Auto04-Near OpenSide Move Out", new PathPlannerAuto("Auto04"));
    autochooser.addOption("Auto05-Near Ampside delay Move Out",new PathPlannerAuto("Auto05"));
    autochooser.addOption("Auto06-Delay Move Out",new PathPlannerAuto("Auto06"));
    autochooser.addOption("Auto07-Auto01 REVERSE (MIDDLE, AMP, STAGE)",new PathPlannerAuto("Auto07"));
    autochooser.addOption("Auto08-Auto01 ALT (MIDDLE, SPEAKER, STOP)",new PathPlannerAuto("Auto08"));
    autochooser.addOption("Auto09-Auto01 ALT (MIDDLE, STOP)",new PathPlannerAuto("Auto09"));    
    SmartDashboard.putData(autochooser);

    //ledchooser.addOption("Lights OFF",0);
    //ledchooser.addOption("Blue",1);
    //ledchooser.addOption("Red",2);
    //ledchooser.addOption("White",3);
    //ledchooser.addOption("Rainbow",4);
    //ledchooser.setDefaultOption("Wave",5);
    //ledchooser.addOption("Siren",6);
    //ledchooser.addOption("Orange",7);
    //SmartDashboard.putData(ledchooser);

    //armmodechooser.setDefaultOption("Auto", false);
    //armmodechooser.addOption("Manual",true);
    //SmartDashboard.putData(armmodechooser);

    // Run button binding method
    configureButtonBindings();
  }

  //------------------------------------B-U-T-T-O-N-S------------------------------------//

  // Create button bindings
  private void configureButtonBindings(){

    new Trigger(() ->m_driverController.getLeftTriggerAxis() >.4).onTrue
                    (new JoystickMultiplier(RobotMap.Driver_Joystick_MultiplierSlow));
    new Trigger(() ->m_driverController.getLeftTriggerAxis() == 0.).onTrue
                    (new JoystickMultiplier(RobotMap.Driver_Joystick_MultiplierNormal));

    new Trigger(() ->m_driverController.getRightTriggerAxis() >.4).onTrue
                    (new JoystickMultiplier(RobotMap.Driver_Joystick_MultiplierFast));
    new Trigger(() ->m_driverController.getRightTriggerAxis() == 0.).onTrue
                    (new JoystickMultiplier(RobotMap.Driver_Joystick_MultiplierNormal));

    new JoystickButton(m_driverController,XBOXconstants.start_button).onTrue (new GyroReset());
    //new JoystickButton(m_driverController,XBOXconstants.back_button).onTrue (new SetWheelsToZero());
    new JoystickButton(m_driverController,XBOXconstants.back_button).onTrue (new SetTargetPosition(RobotMap.AutoSpeakerNearSetup_Index));

    new JoystickButton(m_operatorController, XBOXconstants.A_button).onTrue(new SetTargetPosition(RobotMap.ShooterOff_Index));
    new JoystickButton(m_operatorController, XBOXconstants.B_button).onTrue(new SetTargetPosition(RobotMap.Amp_Index));
    new JoystickButton(m_operatorController, XBOXconstants.Y_button).onTrue(new SetTargetPosition(RobotMap.SpeakerClose_Index));
    new JoystickButton(m_operatorController, XBOXconstants.X_button).onTrue(new SetTargetPosition(RobotMap.SpeakerFar_Index));
    new JoystickButton(m_operatorController, XBOXconstants.back_button).onTrue (new SetTargetPosition(RobotMap.DeliverNote_Index));
    new JoystickButton(m_operatorController, XBOXconstants.bumperLeft).onTrue(new ShooterStop());
    new JoystickButton(m_operatorController, XBOXconstants.bumperRight).onTrue(new ShooterStart());
 
    new Trigger(() ->Robot.myShooter.NoteDectected() && RobotMap.InfeedRunning).debounce(.1).onTrue(new ShooterStop());
  }

  // Return the command to run during auto
  public Command getAutonomousCommand(){
    if (autochooser.getSelected() != null)
            return autochooser.getSelected();
    else return null;
  }

 // public int getLEDdisplay(){
 //   if (ledchooser.getSelected() != null)
 //       return ledchooser.getSelected();
 //   else return 0;
 // }

  // Return the command to run during auto
  // public boolean getArmMode(){
  //   if (armmodechooser.getSelected() != null)
  //      return armmodechooser.getSelected();
  //   else return false;
  // }


  public double  getDriverJoystickStafe() {return -m_driverController.getRawAxis(0);}
  public double  getDriverJoystickForward() {return -m_driverController.getRawAxis(1);}
  public double  getDriverJoystickRotate() {return -m_driverController.getRawAxis(4);}

  public double  getOperatorLeftJoystickValue(){ return m_operatorController.getRawAxis(1);}
  public double  getOperatorRightJoystickValue(){ return m_operatorController.getRawAxis(5);}
  public boolean getOperatorStartButton() { return m_operatorController.getStartButton();}

  
}