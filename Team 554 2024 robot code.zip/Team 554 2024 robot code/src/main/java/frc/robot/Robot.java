
package frc.robot;

import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import com.pathplanner.lib.commands.FollowPathCommand;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.commands.SetTargetPosition;
import frc.robot.commands.SwerveJoystick;
import frc.robot.commands.UpdateArm;
import frc.robot.commands.UpdateClimber;
import frc.robot.commands.UpdateShooter;
import frc.robot.subsystems.Arm;
import frc.robot.subsystems.Camera;
import frc.robot.subsystems.Climber;
import frc.robot.subsystems.LEDcomms;
import frc.robot.subsystems.Pnuematics;
import frc.robot.subsystems.InfeedNote;
import frc.robot.subsystems.Shooter;
import frc.robot.subsystems.SwerveSubsystem;

/**
 * The VM is configured to automatically run this class, and to call the functions corresponding to
 * each mode, as described in the TimedRobot documentation. If you change the name of this class or
 * the package after creating this project, you must also update the build.gradle file in the
 * project.
 */

//@SuppressWarnings("unused")

  public class Robot extends TimedRobot {
  private Command m_autonomousCommand;

  public static final SwerveSubsystem swerveSubsystem = new SwerveSubsystem();
  public static RobotContainer m_robotContainer ;
  public static final LEDcomms myLEDcomms = new LEDcomms();
  public static final Shooter  myShooter  = new Shooter();
  public static final Camera   myCamera = new Camera();
  public static final InfeedNote myInfeedNote = new InfeedNote();
  public static final Arm   myArm = new Arm();
  public static final Pnuematics myPnuematics = new Pnuematics();
  public static final Climber myClimber = new Climber();
 
  @Override
  public void robotInit() {
  	m_robotContainer = new RobotContainer();
    Robot.myCamera.startVisionThread();
		LiveWindow.disableAllTelemetry();
    myArm.setStartupArmPosition();
    swerveSubsystem.resetYaw();
    swerveSubsystem.setDefaultCommand(new SwerveJoystick());
    myArm.setDefaultCommand(new UpdateArm());
    myShooter.setDefaultCommand(new UpdateShooter());
    myClimber.setDefaultCommand(new UpdateClimber());
    FollowPathCommand.warmupCommand().schedule();
    var alliance = DriverStation.getAlliance();
    if (alliance.isPresent()) {
        RobotMap.allianceIsRed = (alliance.get() == DriverStation.Alliance.Red);
        }
    else RobotMap.allianceIsRed = false;
    SmartDashboard.putBoolean("Alliance",RobotMap.allianceIsRed);
    myLEDcomms.setOutputValue(2);
    


  }

  /**
   * This function is called every 20 ms, no matter the mode. Use this for items like diagnostics
   * that you want ran during disabled, autonomous, teleoperated and test.
   *
   * This runs after the mode specific periodic functions, but before LiveWindow and
   * SmartDashboard integrated updating.
   */
  @Override
  public void robotPeriodic() {
   }

  /** This function is called once each time the robot enters Disabled mode. */
  @Override
  public void disabledInit() {}

  @Override
  public void disabledPeriodic() {
    //int LEDcmd;
    //LEDcmd =  m_robotContainer.getLEDdisplay();
    //if (LEDcmd != RobotMap.currentLEDdisplay) {
    //    myLEDcomms.setOutputValue(LEDcmd);
    //    RobotMap.currentLEDdisplay = LEDcmd;
    //    }
    //RobotMap.ArmControlModeManual = m_robotContainer.getArmMode();
  }

  @Override
  public void autonomousInit() {
    RobotMap.AutoGyroOffsetValue = 0.;
    swerveSubsystem.resetYaw();
    RobotMap.inTeleop = false;
    swerveSubsystem.resetAllEncoders();    // Reset all wheel encoders

    // check to see if previous path planner auto is running and cancel if so
    if (m_autonomousCommand  != null) {
        if (m_autonomousCommand.isScheduled()) m_autonomousCommand.cancel();
        m_autonomousCommand = null;
        }

    m_autonomousCommand = m_robotContainer.getAutonomousCommand();;
   	if (m_autonomousCommand != null) m_autonomousCommand.schedule();
    
  }

  /** This function is called periodically during autonomous. */
  @Override
  public void autonomousPeriodic() {
     CommandScheduler.getInstance().run();
  }

  @Override
  public void teleopInit() {
    // This makes sure that the autonomous stops running when teleop starts running.
    // myLEDcomms.setOutputValue(RobotMap.currentLEDdisplay);
    if (m_autonomousCommand != null) {
      m_autonomousCommand.cancel();
    }
    RobotMap.inTeleop = true;
    myPnuematics.TurnOffPusherSolenoid();
    new SetTargetPosition(RobotMap.ShooterOff_Index).schedule();
 
   if (RobotMap.AutoGyroOffsetValue != 0.) {
       var alliance = DriverStation.getAlliance();
       if (alliance.isPresent()) RobotMap.allianceIsRed = (alliance.get() == DriverStation.Alliance.Red);
       else RobotMap.allianceIsRed = false;
       SmartDashboard.putBoolean("Alliance",RobotMap.allianceIsRed);
       if (RobotMap.allianceIsRed) swerveSubsystem.gyro.setAngleAdjustment(-RobotMap.AutoGyroOffsetValue);
       else swerveSubsystem.gyro.setAngleAdjustment(RobotMap.AutoGyroOffsetValue);
    }
    //swerveSubsystem.resetYaw();  
    // Reset all wheel encoders
    swerveSubsystem.resetAllEncoders(); //reset swerve encoders using absolute values and offsets;

  }

  /** This function is called periodically during operator control. */
  @Override
  public void teleopPeriodic() {
     CommandScheduler.getInstance().run();
     if (RobotMap.ResetGyroFlag){
        swerveSubsystem.resetYaw();
        RobotMap.ResetGyroFlag = false;
     }
    }

     
 }
