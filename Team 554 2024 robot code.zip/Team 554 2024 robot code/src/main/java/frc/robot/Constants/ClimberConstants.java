
package frc.robot.Constants;

public final class ClimberConstants{


    public static double  ClimberWindSpeed = -1.0;
    public static double  ClimberUnwindSpeed = .9;
    public static double  ClimberSpoolCircum = (3.14*1.125); // spool diameter is 1", 360 counts pers rev
    public static double  ClimberRetractLimit = .5;
    public static double  ClimberExtendLimitLeft = 20.0;
    public static double  ClimberExtendLimitRight = 19.00;
    public static boolean ClimberLimitOverride = false;

 
}
