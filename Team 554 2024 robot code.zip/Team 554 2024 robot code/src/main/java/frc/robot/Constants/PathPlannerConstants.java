
package frc.robot.Constants;
import frc.robot.Constants.SwerveConstants.DriveConstants;
import com.pathplanner.lib.util.HolonomicPathFollowerConfig;
import com.pathplanner.lib.util.PIDConstants;
import com.pathplanner.lib.util.ReplanningConfig;

//import edu.wpi.first.math.trajectory.TrapezoidProfile;

public final class PathPlannerConstants {


        public static final double kFieldWidth = 8.0137;

        // ********************************pathplanner auto constants
        public static final HolonomicPathFollowerConfig pathFollowerConfig = new HolonomicPathFollowerConfig(
            new PIDConstants(5., 0., 0.), // Translation constants  sds test = 5.0
            new PIDConstants(5., 0.0, 0.0), // Rotation constants     sds test = 1.5
            3.0,   //was 4.5
            DriveConstants.kDriveBaseRadius, // Drive base radius in meters 
            new ReplanningConfig() );
    

}
