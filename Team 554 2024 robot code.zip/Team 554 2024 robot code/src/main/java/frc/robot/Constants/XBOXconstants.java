
package frc.robot.Constants;

public final class XBOXconstants {

        public  static int A_button = 1;
        public	static int B_button = 2;
        public	static int X_button = 3;
        public	static int Y_button = 4;
        public	static int bumperLeft = 5; 
        public	static int bumperRight = 6;
        public  static int back_button = 7;
        public  static int start_button = 8;

}
