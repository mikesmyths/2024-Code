
package frc.robot.Constants;

public final class CameraConstants{


    public static int    cameraWidth = 320;
    public static int    cameraHeight = 240;
    public static int    cameraFR = 20;

 
}
