
package frc.robot.Constants;
import edu.wpi.first.math.util.Units;

public final class SwerveConstants {
    public static final double JoystickDeadband = 0.05;

    // Swerve modules
    public static final class ModuleConstants {
        public static final double kWheelDiameterMeters = Units.inchesToMeters(3.89);
        public static final double kDriveMotorGearRatio = 1 / 6.67 ; 
        public static final double kTurningMotorGearRatio = 1 / 12.8;
        public static final double kDriveEncoderRot2Meter = kDriveMotorGearRatio * Math.PI * kWheelDiameterMeters;
        public static final double kTurningEncoderRot2Rad = kTurningMotorGearRatio * 2. * Math.PI;  //radians in one turn of wheel shaft
        public static final double kDriveEncoderRPM2MeterPerSec = kDriveEncoderRot2Meter / 60.;
        public static final double kTurningEncoderRPM2RadPerSec = kTurningEncoderRot2Rad / 60.;
//
// ***********************drive motor wheel speed pid constants ******  not in use
        public static final double kPDriving = 0.2;
        public static final double kIDriving = 0.0000;
        public static final double kDDriving = 0.0;
// ***********************drive turning motor pid constants *******  not in use      
        public static final double kPTurning = 0.35;
        public static final double kITurning = 0.2 ;
        public static final double kDTurning = 0.00;
       
    }

    // Swerve drive
    public static final class DriveConstants {

         // Distance between right and left wheels
         public static final double kTrackWidth = Units.inchesToMeters(23.5);

         // Distance between front and back wheels
         public static final double kWheelBase = Units.inchesToMeters(23.5);
         public static final double kDriveBaseRadius = 
               Math.sqrt(Math.pow(kTrackWidth/2.,2.)+ Math.pow(kWheelBase/2.,2.));
        public static final int kFrontLeftDriveMotorPort = 1;  // Front Left 
        public static final int kFrontRightDriveMotorPort = 3; // Front Right
        public static final int kBackRightDriveMotorPort = 5;  // Back Right
        public static final int kBackLeftDriveMotorPort = 7;   // Back Left

                                                                // Turning Motor Ports
        public static final int kFrontLeftTurningMotorPort = 2; // Front Left
        public static final int kFrontRightTurningMotorPort = 4;// Front Right
        public static final int kBackRightTurningMotorPort = 6; // Back Right
        public static final int kBackLeftTurningMotorPort = 8;  // Back Left

        // Encoder on NEO turning
        public static final boolean kFrontLeftTurningMotorReversed = false;
        public static final boolean kBackLeftTurningMotorReversed = false;
        public static final boolean kFrontRightTurningMotorReversed = false;
        public static final boolean kBackRightTurningMotorReversed = false;

        // Encoder for NEO drive
        public static final boolean kFrontLeftDriveMotorReversed = true;
        public static final boolean kFrontRightDriveMotorReversed = true; 
        public static final boolean kBackRightDriveMotorReversed = true;
        public static final boolean kBackLeftDriveMotorReversed = true;

        // -------> ABE <-------- //
        public static final int kFrontLeftDriveAbsoluteEncoderPort = 1;
        public static final int kFrontRightDriveAbsoluteEncoderPort = 2;
        public static final int kBackRightDriveAbsoluteEncoderPort = 3;
        public static final int kBackLeftDriveAbsoluteEncoderPort = 4;
        // -------> ABE <-------- //

        // Absolute encoders reversed
        public static final boolean kFrontLeftDriveAbsoluteEncoderReversed = false;
        public static final boolean kFrontRightDriveAbsoluteEncoderReversed = false;
        public static final boolean kBackLeftDriveAbsoluteEncoderReversed = false;
        public static final boolean kBackRightDriveAbsoluteEncoderReversed = false;

        public static final double kFrontLeftDriveAbsoluteEncoderOffsetDeg = -(121.2955+8.78);
        public static final double kFrontRightDriveAbsoluteEncoderOffsetDeg = 25.7258-1.2;
        public static final double kBackRightDriveAbsoluteEncoderOffsetDeg =  -(44.5761+3.25);
        public static final double kBackLeftDriveAbsoluteEncoderOffsetDeg = -(118.2585+1.84);

        public static final double kPhysicalMaxSpeedMetersPerSecond = 3.5;
        public static final double kPhysicalMaxAngularSpeedRadiansPerSecond = 1.5 * Math.PI;

        public static final double kTeleDriveMaxSpeedMetersPerSecond = kPhysicalMaxSpeedMetersPerSecond;
        public static final double kTeleDriveMaxAngularSpeedRadiansPerSecond = kPhysicalMaxAngularSpeedRadiansPerSecond;
        public static final double kTeleDriveMaxAccelerationUnitsPerSecond = 3.; 
        public static final double kTeleDriveMaxAngularAccelerationUnitsPerSecond = kPhysicalMaxAngularSpeedRadiansPerSecond ; 
    }
 
}
