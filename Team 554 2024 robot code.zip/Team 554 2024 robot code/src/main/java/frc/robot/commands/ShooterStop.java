package frc.robot.commands;

import frc.robot.Robot;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;


public class ShooterStop extends Command {

    public ShooterStop() {
        // Use requires() here to declare subsystem dependencies
        // eg. requires(chassis);
    }

    // Called just before this Command runs the first time
    @Override
    public void initialize() {
    }

    // Called repeatedly when this Command is scheduled to run
    @Override
    public void execute() {
    }

    // Make this return true when this Command no longer needs to run execute()
    @Override
    public boolean isFinished() {
        return true;
    }

    // Called once after isFinished returns true
    @Override
    public void end(boolean interrupted) {
        RobotMap.ShooterSetPoint = 0.;
        SmartDashboard.putBoolean("Note in Shooter",Robot.myShooter.NoteDectected());
        if (Robot.myShooter.NoteDectected()) Robot.myLEDcomms.setOutputValue(2);
        else Robot.myLEDcomms.setOutputValue(0);
        Robot.myInfeedNote.InfeedMotorSetSpeed(0.); // turn off infeed if on
        RobotMap.ShooterRunning = false;
        RobotMap.InfeedRunning = false;
        SmartDashboard.putBoolean("Shooter Running", false);
 		SmartDashboard.putBoolean("Infeed Running",false);
    }

}
