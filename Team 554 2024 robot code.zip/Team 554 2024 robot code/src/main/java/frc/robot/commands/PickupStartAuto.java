//
// this is used to both start the shooter in the pickup position and also to shoot a note
// when the arm is in a shoot position.
//
// for pickup the shooter is turned on and left on and the command immediately is done
//
// Shooting consists of turning the shooter on and operating the pusher to feed a note into the wheels.
// The shooter is turned on automaticlly when the arm is raised to a shooting position. If the shooter
// was stopped it will be turned on and the pusher timing and end of shoot timing is changed to allow
// the shooter to come up to speed, the pusher to be activated and retracted and the note to exit the shooter.
//
// when shoot sequence is complete the arm is returned to the pickup postion  

package frc.robot.commands;

import frc.robot.Robot;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;

	public class PickupStartAuto extends Command {

		public PickupStartAuto() {
			}

	    // Called just before this Command runs the first time
	    public void initialize() {
			if (RobotMap.ArmSetpointIndex < 2) {
				Robot.myInfeedNote.InfeedMotorSetSpeed(RobotMap.InfeedMotorSpeed);
				RobotMap.ShooterSetPoint = RobotMap.ShooterSetpoints[1];
				RobotMap.InfeedRunning = true;
				SmartDashboard.putBoolean("Infeed Running",true);
			}
		}


	    // Called repeatedly when this Command is scheduled to run
	    public void execute() {
		}	

	    // done immediatly if arm is in pickup or after pusher was activated and time to ensure note output is elapsed.
	    public boolean isFinished() {
	        return true;
	    }

	    // Called once after isFinished returns true
	    public void end(boolean interrupted) {
			}

	}
