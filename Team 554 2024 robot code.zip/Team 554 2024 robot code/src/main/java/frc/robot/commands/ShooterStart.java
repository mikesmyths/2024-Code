//
// this is used to both start the shooter in the pickup position and also to shoot a note
// when the arm is in a shoot position.
//
// for pickup the shooter is turned on and left on and the command immediately is done
//
// Shooting consists of turning the shooter on and operating the pusher to feed a note into the wheels.
// The shooter is turned on automaticlly when the arm is raised to a shooting position. If the shooter
// was stopped it will be turned on and the pusher timing and end of shoot timing is changed to allow
// the shooter to come up to speed, the pusher to be activated and retracted and the note to exit the shooter.
//
// when shoot sequence is complete the arm is returned to the pickup postion  

package frc.robot.commands;

import frc.robot.Robot;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;

	public class ShooterStart extends Command {

		int complete_count;
        int startpusher_count;
		int stoppusher_count;
		int loopcount;

		public ShooterStart() {
			}

	    // Called just before this Command runs the first time
	    public void initialize() {
			loopcount = 0;
			if (RobotMap.ShooterRunning) {  //shooter already started
				startpusher_count = 1;
				stoppusher_count = 10;
				complete_count = 20;
				}
			else {
				startpusher_count = 50;
				stoppusher_count = 60;
				complete_count = 80;
			}
			if (RobotMap.ArmSetpointIndex < 2) {
				Robot.myInfeedNote.InfeedMotorSetSpeed(RobotMap.InfeedMotorSpeed);
				RobotMap.ShooterSetPoint = RobotMap.ShooterSetpoints[1];
				RobotMap.InfeedRunning = true;
				SmartDashboard.putBoolean("Infeed Running",true);
			}
			else {
				RobotMap.ShooterSetPoint = RobotMap.ShooterSetpoints[RobotMap.ShooterSetpointIndex];
				RobotMap.ShooterRunning = true;
				SmartDashboard.putBoolean("Shooter Running",true);
				}
		}


	    // Called repeatedly when this Command is scheduled to run
	    public void execute() {
			loopcount+=1;
			  // turn note pusher on and off when in shooting position 
			if ((loopcount == startpusher_count) && (RobotMap.ArmSetpointIndex > 1) )
			   Robot.myPnuematics.TurnOnPusherSolenoid() ;
			if ((loopcount == stoppusher_count) && (RobotMap.ArmSetpointIndex > 1) )
			   Robot.myPnuematics.TurnOffPusherSolenoid(); ;
	    	}

	    // done immediatly if arm is in pickup or after pusher was activated and time to ensure note output is elapsed.
	    public boolean isFinished() {
	        return ((loopcount > complete_count) || (RobotMap.ArmSetpointIndex <2));
	    }

	    // Called once after isFinished returns true
	    public void end(boolean interrupted) {
			// arm is returned to pickup position and shooter turned off if it was in a shoot position
			if (RobotMap.ArmSetpointIndex > 1) {
				RobotMap.ShooterSetpointIndex = 0;
				RobotMap.ArmSetpointIndex = 0;
				RobotMap.ArmFinalPositionIndex = 0;
				RobotMap.ShooterSetPoint = 0.;
				RobotMap.ArmPositionSetpoint = 0.;
				RobotMap.ShooterRunning = false;
				RobotMap.InfeedRunning = false;
				Robot.myInfeedNote.InfeedMotorSetSpeed(0.);
				SmartDashboard.putBoolean("Note in Shooter",Robot.myShooter.NoteDectected());
				if (Robot.myShooter.NoteDectected()) Robot.myLEDcomms.setOutputValue(2);
				else Robot.myLEDcomms.setOutputValue(0);
				SmartDashboard.putBoolean("Shooter Running", false);
				SmartDashboard.putBoolean("Infeed Running",false);
				SmartDashboard.putString("Target Position", RobotMap.PostionTargetLabels[0]);
				RobotMap.ArmInTargetPosition = false;
				SmartDashboard.putBoolean("Arm At Target Position", false);
			}
	    }
	}
