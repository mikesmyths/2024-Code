package frc.robot.commands;

import frc.robot.Robot;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.math.MathUtil;

public class MoveDistAtAngle extends Command {

	private double MoveDistance;
    private double MoveSpeed;
    private double MoveAngle;
    private double RampDistance;
    
    private double dts;    // distance to slow down
    private double dta;    // distance to accel
    private double dcur;   //current distance
    private double str;    // str component of angle
    private double fwd;    // fwd component of angle

    private double scmd;
    private double s = 0.;
    private double dcmd;
    private double mcmd = .05;
    private double currentGyro;
    private double heading;
    private double temp;

    public MoveDistAtAngle(double cmdMoveDistance, double cmdMoveSpeed, double cmdMoveAngle,
    double cmdRampDistance, double cmdHeading) {

    //addRequirements(Robot.gyroSwerveDrive);

    // MoveDistance = absolute distance to travel in meters
    // MoveSpeed = absolute speed in range of .05 min to 3.5 meters/sec
    // MoveAngle = angle of linear move relative field as a joystick vector
    // RampDistance = distance in meters at begining and end of travel to ramp from min to move speed to min
    // Orientation = gyro heading to rotate to or maintain during travel

    this.MoveDistance = cmdMoveDistance;
    this.MoveSpeed = cmdMoveSpeed;
    this.RampDistance = cmdRampDistance;
    this.MoveAngle = cmdMoveAngle;
    this.str = Math.sin(Math.toRadians(MoveAngle));
    this.fwd = -Math.cos(Math.toRadians(MoveAngle));
    this.heading = cmdHeading;
    }

    // Called just before this Command runs the first time
    @Override
    public void initialize() {
        }

    // Called repeatedly when this Command is scheduled to run
    @Override
    public void execute() {
    // dmcd = distance to travel absolute
    // dta =  distance to accel at start of move
    // dts =  distance where decel starts at end of move
    // mcmd = minimum speed
    // scmd = speed value for middle of travel.  This is adjusted if ramp distance * 2 < total distance
    // s = speed value calculated when ramping up or down
    // dcur = current distance traveled in path

    dcmd = Math.abs(MoveDistance);
    dts = (dcmd <= RampDistance*2.) ? dcmd/2. : RampDistance;
    dta = dts;
    scmd = (dcmd <= RampDistance*2.) ? (MoveSpeed-mcmd)/2.+mcmd : MoveSpeed;
    dcur = Math.abs(Robot.swerveSubsystem.getDrivePosition());  // current move actual distance

    // calculate the speeds in the ramp up and ramp down portions of the move
    s = scmd;
    if (dcur < dta ) {  // ramp speed up to speed to accel distance
        s = ((scmd-mcmd)/dta)*dcur + mcmd;	
        }
    if (dcur > (dcmd-dts) ) {  // beyond slowdown point
        s = scmd  - (scmd -mcmd) * (1.0 - (dcmd - dcur)/dts);
        }
    currentGyro = Robot.swerveSubsystem.getHeading();
    temp = MathUtil.clamp((heading - currentGyro) * .01,-.1,.1); // keeps orientation of machine with gyro
    RobotMap.driveMoveAtAngleForward = fwd*s;
    RobotMap.driveMoveAtAngleStraf = str*s;
    RobotMap.driveMoveAtAngleRotation = temp;
    
    }

    // Make this return true when this Command no longer needs to run execute()
    @Override
    public boolean isFinished() {
        return (dcur >= dcmd);
        }

    // Called once after isFinished returns true
    @Override
    public void end(boolean interrupted) {
    RobotMap.driveMoveAtAngleForward = 0.;
    RobotMap.driveMoveAtAngleStraf = 0.;
    RobotMap.driveMoveAtAngleRotation = 0.;
    }

}
