
package frc.robot.commands;
// this is the default command that runs to keep the climber system updated

import frc.robot.Robot;
import edu.wpi.first.wpilibj2.command.Command;

//@SuppressWarnings("unused")

public class UpdateClimber extends Command {

  // Create variables
  
   // Command constructor
  public UpdateClimber() {

  addRequirements(Robot.myClimber);

  }

  @Override
  public void initialize() {
   }

  // Running loop of command
  @Override
  public void execute(){
    Robot.myClimber.moveClimberWithJoystick(Robot.m_robotContainer.getOperatorLeftJoystickValue(),
                                            Robot.m_robotContainer.getOperatorStartButton());
}

  // Stop all module motor movement when command ends
  @Override
  public void end(boolean interrupted){}

  @Override
  public boolean isFinished(){return false;}

}
