package frc.robot.commands;

import frc.robot.RobotMap;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;

	public class SetTargetPosition extends Command {

		int TargetIndex;

		public SetTargetPosition(int targetindex) {
			TargetIndex = targetindex;
			}

	    // Called just before this Command runs the first time
	    public void initialize() {
		}


	    public void execute() {
	    }

	    // done when is arm is in home postion or .25 second after pusher was activated.
	    public boolean isFinished() {
	        return true;
	    }

	    // Called once after isFinished returns true
	    public void end(boolean interrupted) {
			RobotMap.ShooterSetpointIndex = TargetIndex;
			RobotMap.ArmFinalPositionIndex = TargetIndex;
			RobotMap.ArmSetpointIndex = TargetIndex;
			if (TargetIndex == RobotMap.SpeakerFar_Index) {
			     RobotMap.ArmPositionSetpoint = RobotMap.ArmPositionSetpoints[RobotMap.SpeakerClose_Index];
				 RobotMap.ArmSetpointIndex = RobotMap.SpeakerClose_Index;
				 }
				 // move arm to higher position it will be returned to actual target in the arm routine
				 // this is used only on the speakerfar shooting target angle
			else RobotMap.ArmPositionSetpoint = RobotMap.ArmPositionSetpoints[TargetIndex];
			SmartDashboard.putString("Target Position", RobotMap.PostionTargetLabels[TargetIndex]);
			RobotMap.ArmInTargetPosition = false;
			SmartDashboard.putBoolean("Arm At Target Position", false);
	}

	}
