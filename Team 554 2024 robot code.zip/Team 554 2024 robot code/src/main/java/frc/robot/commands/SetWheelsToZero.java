//
// this is used to both start the shooter in the pickup position and also to shoot a note
// when the arm is in a shoot position.
//
// for pickup the shooter is turned on and left on and the command immediately is done
//
// Shooting consists of turning the shooter on and operating the pusher to feed a note into the wheels.
// The shooter is turned on automaticlly when the arm is raised to a shooting position. If the shooter
// was stopped it will be turned on and the pusher timing and end of shoot timing is changed to allow
// the shooter to come up to speed, the pusher to be activated and retracted and the note to exit the shooter.
//
// when shoot sequence is complete the arm is returned to the pickup postion  

package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Robot;

	public class SetWheelsToZero extends Command {

		int complete_count;
		int loopcount;

		public SetWheelsToZero() {
			}

	    // Called just before this Command runs the first time
	    public void initialize() {
			loopcount = 0;
			complete_count = 5;
		}

	    // Called repeatedly when this Command is scheduled to run
	    public void execute() {
			loopcount += 1;
			Robot.swerveSubsystem.SetWheelsToZero();
	    	}

	    // done immediatly if arm is in pickup or after pusher was activated and time to ensure note output is elapsed.
	    public boolean isFinished() {
	        return (loopcount > complete_count);
	    }

	    // Called once after isFinished returns true
	    public void end(boolean interrupted) {

	    }
	}
