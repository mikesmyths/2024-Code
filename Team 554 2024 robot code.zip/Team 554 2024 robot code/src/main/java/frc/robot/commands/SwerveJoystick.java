
package frc.robot.commands;

import frc.robot.Robot;
import frc.robot.RobotMap;
import frc.robot.Constants.SwerveConstants;
import frc.robot.Constants.SwerveConstants.DriveConstants;

import edu.wpi.first.math.filter.SlewRateLimiter;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj2.command.Command;

//@SuppressWarnings("unused")

public class SwerveJoystick extends Command {

  // Create variables
  //private final SwerveSubsystem swerveSubsystem; 
  private final SlewRateLimiter xLimiter, yLimiter, turningLimiter;
 
  
  
   // Command constructor
public SwerveJoystick(){
  // Slew rate limiter
  xLimiter = new SlewRateLimiter(SwerveConstants.DriveConstants.kTeleDriveMaxAccelerationUnitsPerSecond);
  yLimiter = new SlewRateLimiter(SwerveConstants.DriveConstants.kTeleDriveMaxAccelerationUnitsPerSecond);
  turningLimiter = new SlewRateLimiter(SwerveConstants.DriveConstants.kTeleDriveMaxAngularAccelerationUnitsPerSecond);

  // Tell command that it needs swerveSubsystem
  addRequirements(Robot.swerveSubsystem);

  }

  @Override
  public void initialize() {
   }

  // Running loop of command
  @Override
  public void execute(){
    if (RobotMap.inTeleop) {
      // Set joystick inputs to speed variables
      double xSpeed = Robot.m_robotContainer.getDriverJoystickForward();
      double ySpeed = Robot.m_robotContainer.getDriverJoystickStafe();
      double turningSpeed = Robot.m_robotContainer.getDriverJoystickRotate();
 
      // Apply deadband to protect motors
      xSpeed = Math.abs(xSpeed) > SwerveConstants.JoystickDeadband ? xSpeed : 0.0;
      ySpeed = Math.abs(ySpeed) > SwerveConstants.JoystickDeadband ? ySpeed : 0.0;
      turningSpeed = Math.abs(turningSpeed) > SwerveConstants.JoystickDeadband ? turningSpeed : 0.0;

      // Apply slew rate to joystick input to make robot input smoother and mulitply by max speed
      xSpeed = xLimiter.calculate(xSpeed) * DriveConstants.kTeleDriveMaxSpeedMetersPerSecond * RobotMap.Driver_Joystick_Multiplier;
      ySpeed = yLimiter.calculate(ySpeed) * DriveConstants.kTeleDriveMaxSpeedMetersPerSecond * RobotMap.Driver_Joystick_Multiplier;
      turningSpeed = turningLimiter.calculate(turningSpeed) *
          DriveConstants.kTeleDriveMaxAngularSpeedRadiansPerSecond * RobotMap.Driver_Joystick_Multiplier;

      // Create chassis speeds
      ChassisSpeeds chassisSpeeds;

      chassisSpeeds = ChassisSpeeds.fromFieldRelativeSpeeds(xSpeed, ySpeed, turningSpeed,
            Rotation2d.fromDegrees(Robot.swerveSubsystem.getRobotDegrees()));
 
      // Create module states using array
      SwerveModuleState[] moduleStates = Robot.swerveSubsystem.kDriveKinematics.toSwerveModuleStates(chassisSpeeds);

      // Set the module state
      Robot.swerveSubsystem.setModuleStates(moduleStates);
    }
  }

  // Stop all module motor movement when command ends
  @Override
  public void end(boolean interrupted){Robot.swerveSubsystem.stopModules();}

  @Override
  public boolean isFinished(){return false;}

}
