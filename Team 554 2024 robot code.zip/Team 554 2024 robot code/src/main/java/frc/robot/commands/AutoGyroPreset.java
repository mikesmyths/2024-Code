package frc.robot.commands;

import frc.robot.RobotMap;
import edu.wpi.first.wpilibj2.command.Command;

	public class AutoGyroPreset extends Command {
		private double myGyroOffset;

		public AutoGyroPreset(double GyroOffset) {
			myGyroOffset = GyroOffset;
			}

	    // Called just before this Command runs the first time
	    public void initialize() {
			RobotMap.AutoGyroOffsetValue = myGyroOffset;
		}


	    public void execute() {
	    }

	    // done when is arm is in home postion or .25 second after pusher was activated.
	    public boolean isFinished() {
	        return true;
	    }

	    // Called once after isFinished returns true
	    public void end(boolean interrupted) {
	}

	}
