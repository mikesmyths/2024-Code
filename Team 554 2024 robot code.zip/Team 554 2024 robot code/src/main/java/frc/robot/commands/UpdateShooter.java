
package frc.robot.commands;
// this is the default command that runs to keep the shooter system updated

import frc.robot.Robot;
import frc.robot.RobotMap;
import edu.wpi.first.wpilibj2.command.Command;

//@SuppressWarnings("unused")

public class UpdateShooter extends Command {

  // Create variables
  
   // Command constructor
  public UpdateShooter() {

  addRequirements(Robot.myShooter);

  }

  @Override
  public void initialize() {
   }

  // Running loop of command
  @Override
  public void execute(){
   Robot.myShooter.UpdateShooter(RobotMap.ShooterSetPoint);
  }

  // Stop all module motor movement when command ends
  @Override
  public void end(boolean interrupted){}

  @Override
  public boolean isFinished(){return false;}

}
