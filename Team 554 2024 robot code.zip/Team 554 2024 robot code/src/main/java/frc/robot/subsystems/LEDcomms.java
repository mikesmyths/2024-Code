package frc.robot.subsystems;

import edu.wpi.first.wpilibj.DigitalOutput;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class LEDcomms extends SubsystemBase {

	private DigitalOutput bit0, bit1, bit2, bit3;

	public LEDcomms() {
		super();

	bit0 = new DigitalOutput(6);
	bit1 = new DigitalOutput(7);
	bit2 = new DigitalOutput(8);
	bit3 = new DigitalOutput(9);
}

	
	public void setOutputValue(int outputValue) {
		bit0.set((outputValue & 1 ) == 1);
		bit1.set((outputValue & 2 ) == 2);
		bit2.set((outputValue & 4 ) == 4);
		bit3.set((outputValue & 8 ) == 8);
		}

    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
	}

}
