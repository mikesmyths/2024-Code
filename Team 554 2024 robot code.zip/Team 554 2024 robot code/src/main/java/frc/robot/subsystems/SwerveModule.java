
package frc.robot.subsystems;
//import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.SwerveConstants.ModuleConstants;

import com.ctre.phoenix6.configs.CANcoderConfiguration;
import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.signals.AbsoluteSensorRangeValue;
import com.revrobotics.CANSparkBase;
import com.revrobotics.CANSparkLowLevel;
import com.revrobotics.CANSparkMax;
import com.revrobotics.SparkRelativeEncoder;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.SparkPIDController;

public class SwerveModule extends SubsystemBase {
 
  // Create empty variables for reassignment
  private final CANSparkMax driveMotor;
  private final CANSparkMax turningMotor;

  private final RelativeEncoder driveEncoder;
  private final RelativeEncoder turningEncoder;

  //private final PIDController drivingPidController;
  private final PIDController turningPidController;
  private final SparkPIDController SparkMaxDrivePIDController;

  private final CANcoder  absoluteEncoder;
  
  private String moduleName;

  // Class constructor where we assign default values for variable
   public SwerveModule(int driveMotorId,
                       int turningMotorId,
                   boolean driveMotorReversed, 
                   boolean turningMotorReversed,
                       int absoluteEncoderId,
                    double absoluteEncoderOffsetDeg,
                   boolean absoluteEncoderReversed,
                    String name) {

  
    moduleName = name;
    name = moduleName;  // added this to prevent not used warning value is used with Smartdashboard stuff

    //SmartDashboard.putNumber(moduleName + " ABE Manual", 0);

    // Create absolute encoder
    absoluteEncoder = new CANcoder(absoluteEncoderId,"canivor1");
    CANcoderConfiguration cc_cfg = new CANcoderConfiguration();
    cc_cfg.MagnetSensor.AbsoluteSensorRange = AbsoluteSensorRangeValue.Signed_PlusMinusHalf;
    cc_cfg.MagnetSensor.MagnetOffset = absoluteEncoderOffsetDeg/360.;  // magnetic offset unit is rotation
    absoluteEncoder.getConfigurator().apply(cc_cfg);
     
    // Create drive and turning motor
    driveMotor = new CANSparkMax(driveMotorId, CANSparkLowLevel.MotorType.kBrushless);
    turningMotor = new CANSparkMax(turningMotorId, CANSparkLowLevel.MotorType.kBrushless);

    // Set reverse state of drive and turning motor
    driveMotor.setInverted(driveMotorReversed);
    turningMotor.setInverted(turningMotorReversed);

    // Set drive and turning motor encoder values
    driveEncoder = driveMotor.getEncoder(SparkRelativeEncoder.Type.kHallSensor,42);
    turningEncoder = turningMotor.getEncoder(SparkRelativeEncoder.Type.kHallSensor,42);

    // Change drive motor conversion factors
    driveEncoder.setPositionConversionFactor(ModuleConstants.kDriveEncoderRot2Meter);
    driveEncoder.setVelocityConversionFactor(ModuleConstants.kDriveEncoderRPM2MeterPerSec);

    // Change conversion factors for neo turning encoder - should be in radians!
    turningEncoder.setPositionConversionFactor(ModuleConstants.kTurningEncoderRot2Rad); // neo  1/12.8*2*pi
    turningEncoder.setVelocityConversionFactor(ModuleConstants.kTurningEncoderRPM2RadPerSec); // position /60
    var cancoderPos = absoluteEncoder.getAbsolutePosition();
    turningEncoder.setPosition( cancoderPos.getValueAsDouble());

    // Create PID controllers for wheel speed and angle on ROBO RIO
    //drivingPidController = new PIDController(ModuleConstants.kPDriving, ModuleConstants.kITurning, 0);
    turningPidController = new PIDController(.3,.2, 0);
    turningPidController.setIntegratorRange(-0.1, 0.1);

    // Create PID controller for wheel speed on Sparkmax  *********** pid on drive wheels speed ********
    SparkMaxDrivePIDController  = driveMotor.getPIDController();
    // PID coefficients
    SparkMaxDrivePIDController.setP(.4); //.3
    SparkMaxDrivePIDController.setI(0.0); //.0
    SparkMaxDrivePIDController.setD(0.);
    SparkMaxDrivePIDController.setIZone(0.);
    SparkMaxDrivePIDController.setFF(.215); // .2
    SparkMaxDrivePIDController.setOutputRange(-1., 1.);
   
    // Tell PID controller that it is a *wheel*
    turningPidController.enableContinuousInput(-Math.PI, Math.PI);

    driveMotor.setIdleMode(CANSparkBase.IdleMode.kBrake);
    turningMotor.setIdleMode(CANSparkBase.IdleMode.kBrake);

    driveMotor.setSmartCurrentLimit(40);
    turningMotor.setSmartCurrentLimit(20);
    
    resetEncoders();

  }

  public void update(){
    //SmartDashboard.putNumber(moduleName + " Absolute-Position ", getAbsoluteEncoderRad()*180./Math.PI);
    //SmartDashboard.putNumber(moduleName + " Distance ",Units.metersToInches(driveEncoder.getPosition()));
  }

  // Helpful get methods
  public double getDrivePosition() {
    return driveEncoder.getPosition();
  }

  public double getTurningPosition() {
      return getAbsoluteEncoderRad();
    }

  public double getDriveVelocity() {
      return driveEncoder.getVelocity();
    }

  public double getTurningVelocity() {
      return turningEncoder.getVelocity();
    }
    
  public SwerveModulePosition getPosition(){
    return( new SwerveModulePosition(
      getDrivePosition(), new Rotation2d(getTurningPosition())));
  }

  // Convert absolute value of the encoder. Cancoder already set to radians
  public double getAbsoluteEncoderRad(){
    double angle;
    var cancoderPos = absoluteEncoder.getAbsolutePosition();  // returns value in +- .5 rotations
    angle = cancoderPos.getValueAsDouble()*2.* Math.PI; // convert to radians
    return angle;
  }

  // Set turning encoder to match absolute encoder value with gear offsets applied
  public void resetEncoders(){
    driveEncoder.setPosition(0);
    turningEncoder.setPosition(getAbsoluteEncoderRad());
  }

  // Get swerve module current state, aka velocity and wheel rotation
  public SwerveModuleState getState(){
    return new SwerveModuleState(getDriveVelocity(), new Rotation2d(getTurningPosition()));
  }

 
  //  ****************** code to output desired states using PID loops for drive and steer **********************
  public void setDesiredState(SwerveModuleState state){
    double turnPIDtarget;

    // Check if new command has high driving power 
    if(Math.abs(state.speedMetersPerSecond) < 0.001){
      stop();
      return;
    }
    // Optimize swerve module state to do fastest rotation movement, aka never rotate more than 90*
    state = SwerveModuleState.optimize(state, getState().angle);

    // Use external PID to set wheel speeds to state target speed
     SparkMaxDrivePIDController.setReference(state.speedMetersPerSecond, CANSparkMax.ControlType.kVelocity);

    // Use internal PID to set wheel angle setpoint  position loop
    turnPIDtarget = state.angle.getRadians();
    turningMotor.set(turningPidController.calculate(getTurningPosition(), turnPIDtarget));
  
    //SmartDashboard.putNumber(moduleName + " wheel setp ", state.speedMetersPerSecond);
    //SmartDashboard.putNumber(moduleName + " angle setp ", state.angle.getRadians());
  }
  // **************************************************************************************************************


  // Stop all motors on module 
  public void stop() {
    driveMotor.set(0);
    turningMotor.set(0);
  }

  // Set wheel to zero position
  public void wheelToZero() {
    turningMotor.set(turningPidController.calculate(getTurningPosition(), 0.));
  }

  // Motor and SparkMax methods for Monitor 
  public double[] getMotorsCurrent(){
    return(new double[]{driveMotor.getOutputCurrent(),turningMotor.getOutputCurrent()});
  }

  public double[] getMotorsTemp(){
    return(new double[]{driveMotor.getMotorTemperature(),turningMotor.getMotorTemperature()});
  }

  public void setSmartCurrentLimiter(int driveLimit, int turningLimit){
    driveMotor.setSmartCurrentLimit(driveLimit);
    turningMotor.setSmartCurrentLimit(driveLimit);
  }

}
