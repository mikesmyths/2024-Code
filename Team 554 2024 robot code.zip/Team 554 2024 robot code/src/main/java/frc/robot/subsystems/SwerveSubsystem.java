
package frc.robot.subsystems;
import com.kauailabs.navx.frc.AHRS;
import com.pathplanner.lib.auto.AutoBuilder;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.kinematics.SwerveDriveKinematics;
import edu.wpi.first.math.kinematics.SwerveDriveOdometry;
import edu.wpi.first.math.kinematics.SwerveModulePosition;
import edu.wpi.first.math.kinematics.SwerveModuleState;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.PathPlannerConstants;
import frc.robot.Constants.SwerveConstants.DriveConstants;

public class SwerveSubsystem extends SubsystemBase {
  
    // Create 4 swerve modules with attributes from constants
  private final SwerveModule frontLeft = new SwerveModule(
            DriveConstants.kFrontLeftDriveMotorPort,
            DriveConstants.kFrontLeftTurningMotorPort,
            DriveConstants.kFrontLeftDriveMotorReversed,
            DriveConstants.kFrontLeftTurningMotorReversed,
            DriveConstants.kFrontLeftDriveAbsoluteEncoderPort,
            DriveConstants.kFrontLeftDriveAbsoluteEncoderOffsetDeg,
            DriveConstants.kFrontLeftDriveAbsoluteEncoderReversed,
            "Front Left");

    private final SwerveModule frontRight = new SwerveModule(
            DriveConstants.kFrontRightDriveMotorPort,
            DriveConstants.kFrontRightTurningMotorPort,
            DriveConstants.kFrontRightDriveMotorReversed,
            DriveConstants.kFrontRightTurningMotorReversed,
            DriveConstants.kFrontRightDriveAbsoluteEncoderPort,
            DriveConstants.kFrontRightDriveAbsoluteEncoderOffsetDeg,
            DriveConstants.kFrontRightDriveAbsoluteEncoderReversed,
            "Front Right");

    private final SwerveModule backLeft = new SwerveModule(
            DriveConstants.kBackLeftDriveMotorPort,
            DriveConstants.kBackLeftTurningMotorPort,
            DriveConstants.kBackLeftDriveMotorReversed,
            DriveConstants.kBackLeftTurningMotorReversed,
            DriveConstants.kBackLeftDriveAbsoluteEncoderPort,
            DriveConstants.kBackLeftDriveAbsoluteEncoderOffsetDeg,
            DriveConstants.kBackLeftDriveAbsoluteEncoderReversed,
            "Back Left");

    private final SwerveModule backRight = new SwerveModule(
            DriveConstants.kBackRightDriveMotorPort,
            DriveConstants.kBackRightTurningMotorPort,
            DriveConstants.kBackRightDriveMotorReversed,
            DriveConstants.kBackRightTurningMotorReversed,
            DriveConstants.kBackRightDriveAbsoluteEncoderPort,
            DriveConstants.kBackRightDriveAbsoluteEncoderOffsetDeg,
            DriveConstants.kBackRightDriveAbsoluteEncoderReversed,
            "Back Right"); 


    // Create the navX using roboRIO expansion port
    public AHRS gyro = new AHRS(SPI.Port.kMXP);
    

  // Create odometer for swerve drive
  private SwerveDriveOdometry odometer;
  public SwerveDriveKinematics kDriveKinematics;

 // Returns positions of the swerve modules for odometry
    public SwerveModulePosition[] getModulePositions(){
    return( new SwerveModulePosition[]{
      frontLeft.getPosition(), 
      frontRight.getPosition(), 
      backLeft.getPosition(),
      backRight.getPosition()});
    }
   

  // Swerve subsystem constructor
  public SwerveSubsystem() {
    resetAllEncoders();
    kDriveKinematics = new SwerveDriveKinematics(
            new Translation2d(DriveConstants.kWheelBase / 2., DriveConstants.kTrackWidth / 2.), //fl
            new Translation2d(DriveConstants.kWheelBase / 2., -DriveConstants.kTrackWidth / 2.), //fr
            new Translation2d(-DriveConstants.kWheelBase / 2., DriveConstants.kTrackWidth / 2.), //bl
            new Translation2d(-DriveConstants.kWheelBase / 2., -DriveConstants.kTrackWidth / 2.)); //br
            odometer = new SwerveDriveOdometry(kDriveKinematics, 
                getOdometryAngle(), getModulePositions());

  // Configure AutoBuilder last
  AutoBuilder.configureHolonomic(
    this::getPose, 
    this::resetPose, 
    this::getSpeeds, 
    this::driveRobotRelative, 
    PathPlannerConstants.pathFollowerConfig,
    () -> {
      // Boolean supplier that controls when the path will be mirrored for the red alliance
      // This will flip the path being followed to the red side of the field.
      // THE ORIGIN WILL REMAIN ON THE BLUE SIDE

      var alliance = DriverStation.getAlliance();
      if (alliance.isPresent()) {
          return alliance.get() == DriverStation.Alliance.Red;
          }
      else return false;
      },
    this);
  
          }
  
 
  // Reset gyro heading 
  public void zeroHeading() {
    gyro.setAngleAdjustment(0.);
    gyro.reset();
  }

  // Reset gyro yaw
  public void resetYaw(){
      gyro.zeroYaw();
  }

  // Return gyro heading, make sure to read navx docs on this
  public double getHeading(){
    return -gyro.getAngle();
  }

  // Return the robot odometry in pose meters
  public Pose2d getOdometryMeters(){
    return(odometer.getPoseMeters());
  }

  // Return heading in Rotation2d format
  public Rotation2d getRotation2d(){
    return Rotation2d.fromDegrees(this.getHeading());
  }

  // Stop all module movement
  public void stopModules() {
    frontLeft.stop();
    frontRight.stop();
    backLeft.stop();
    backRight.stop();
  }

  // Stop all module movement
  public void SetWheelsToZero() {
    frontLeft.wheelToZero();
    frontRight.wheelToZero();
    backLeft.wheelToZero();
    backRight.wheelToZero();
  }

  // Move the swerve modules to the desired SwerveModuleState
  public void setModuleStates(SwerveModuleState[] desiredStates) {

    // Make sure robot rotation is all ways possible by changing other module rotaion speeds
    SwerveDriveKinematics.desaturateWheelSpeeds(desiredStates, DriveConstants.kPhysicalMaxSpeedMetersPerSecond);
    
    frontLeft.setDesiredState(desiredStates[0]);
    frontRight.setDesiredState(desiredStates[1]);
    backLeft.setDesiredState(desiredStates[2]);
    backRight.setDesiredState(desiredStates[3]);
    }

  // Return robot position caculated by odometer
  public Pose2d getPose(){
    return odometer.getPoseMeters();
      }

  public void resetPose(Pose2d pose) {
      // changed to make sure negation of robot is handled
      // odometer.resetPosition(gyro.getRotation2d(), getPositions(), pose);
      odometer.resetPosition(this.getRotation2d(), getPositions(), pose);
      }   

  public ChassisSpeeds getSpeeds() {
        return kDriveKinematics.toChassisSpeeds(getModuleStates());
  }

  public double getDrivePosition() {
        return backLeft.getDrivePosition();  // this is used by moveDistanceAtAngle command
  }

  public void driveFieldRelative(ChassisSpeeds fieldRelativeSpeeds) {
    driveRobotRelative(ChassisSpeeds.fromFieldRelativeSpeeds(fieldRelativeSpeeds, getPose().getRotation()));
  }

  public void driveRobotRelative(ChassisSpeeds robotRelativeSpeeds) {
    ChassisSpeeds targetSpeeds = ChassisSpeeds.discretize(robotRelativeSpeeds, 0.02);

    SwerveModuleState[] targetStates = kDriveKinematics.toSwerveModuleStates(targetSpeeds);
    setModuleStates(targetStates);
  }

  public SwerveModuleState[] getModuleStates() {
    SwerveModuleState[] states = new SwerveModuleState[4];
        states[0] = frontLeft.getState();
        states[1] = frontRight.getState();
        states[2] = backLeft.getState();
        states[3] = backRight.getState();
    return states;
  }

  public SwerveModulePosition[] getPositions() {
    SwerveModulePosition[] positions = new SwerveModulePosition[4];
        positions[0] = frontLeft.getPosition();
        positions[1] = frontRight.getPosition();
        positions[2] = backLeft.getPosition();
        positions[3] = backRight.getPosition();
    return positions;
  }


  // Reset odometer to new Pose2d location
  public void resetOdometry(Pose2d pose){
   odometer.resetPosition(getOdometryAngle(), getModulePositions(), pose);
  }

  // Reset odometer to new Pose2d location but with roation
  public void resetOdometry(Pose2d pose, Rotation2d rot){
    odometer.resetPosition(rot, getModulePositions(), pose);
  }

  // Return an angle from -180 to 180 for robot odometry
  public Rotation2d getOdometryAngle(){
    return(Rotation2d.fromDegrees(-gyro.getYaw()));
  }

  // Returns an angle from 0 to 360 that is continuous, meaning it loops 
  public double getRobotDegrees(){
    double rawValue = -gyro.getAngle() % 360.0;
    if(rawValue < 0.0){
      return(rawValue + 360.0);
    }else{
      return(rawValue);
    }
  }

  // Reset all swerve module encoders
  public void resetAllEncoders(){
      frontLeft.resetEncoders();
      frontRight.resetEncoders();
      backLeft.resetEncoders();
      backRight.resetEncoders();
  }


  // Periodic looooooop
  @Override
  public void periodic(){

   // Update odometer for it to caculate robot position
   odometer.update(getOdometryAngle(), getModulePositions());

   // Put odometry data on smartdashboard
   //SmartDashboard.putString("Field Location ", getPose().getTranslation().toString());
   //SmartDashboard.putString("ODOMETRY ", odometer.getPoseMeters().toString());
   //SmartDashboard.putString("Raw R2d ROBOT DEG ", getOdometryAngle().toString());
   SmartDashboard.putNumber("NavX Value", getOdometryAngle().getDegrees());
   //SmartDashboard.putNumber("NavX Yaw", gyro.getYaw());
  

  // Update smartdashboard data for each swerve module object
  frontLeft.update();
  frontRight.update();
  backLeft.update();
  backRight.update();

  }
}