package frc.robot.subsystems;

import frc.robot.Constants.ClimberConstants;

import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.TalonSRXControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix6.hardware.CANcoder;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Climber extends SubsystemBase {
	private TalonSRX ClimberMotorLeft;
	private TalonSRX ClimberMotorRight;
	private CANcoder ClimberEncoderLeft;
	private CANcoder ClimberEncoderRight;
	private DigitalInput ClimberLeftLowerLimit;
	private DigitalInput ClimberRightLowerLimit;

	public Climber() {
		super();
		ClimberMotorLeft = new TalonSRX(24);
		ClimberMotorLeft.setInverted(false);
		ClimberMotorLeft.setNeutralMode(NeutralMode.Brake);

		ClimberMotorRight = new TalonSRX(25);
		ClimberMotorRight.setInverted(true);
		ClimberMotorRight.setNeutralMode(NeutralMode.Brake);

		ClimberLeftLowerLimit = new DigitalInput(1);
		ClimberRightLowerLimit = new DigitalInput(2);

		ClimberEncoderLeft = new CANcoder(24,"canivor1");
		ClimberEncoderLeft.setPosition(0.);
		ClimberEncoderRight = new CANcoder(25,"canivor1");
		ClimberEncoderRight.setPosition(0.);

	}


	public void ResetEncoders() {
		ClimberEncoderLeft.setPosition(0.);
		ClimberEncoderRight.setPosition(0.);
	}

	
    public void moveClimberWithJoystick(double LeftJoyStick,boolean StartButtonPressed) {
    	double joystickLeft_value;
		boolean startpressed;
		double currentleft;
		double currentright;
	
		startpressed = StartButtonPressed;
		joystickLeft_value = (startpressed) ?  -LeftJoyStick : 0.;
		currentleft = -ClimberEncoderLeft.getPosition().getValueAsDouble()*ClimberConstants.ClimberSpoolCircum;
		currentright = -ClimberEncoderRight.getPosition().getValueAsDouble()*(-ClimberConstants.ClimberSpoolCircum);


    	if (joystickLeft_value > .1) {
    		if (currentleft < ClimberConstants.ClimberExtendLimitLeft || ClimberConstants.ClimberLimitOverride) {
				ClimberMotorLeft.set(TalonSRXControlMode.PercentOutput,joystickLeft_value);
			} 
			else {
				ClimberMotorLeft.set(TalonSRXControlMode.PercentOutput,0.);
			}
    	}
    	else if (joystickLeft_value < -.1) {
    		if (ClimberLeftLowerLimit.get()) {        // returns true until sensor encounters magnet.
				ClimberMotorLeft.set(TalonSRXControlMode.PercentOutput,joystickLeft_value);
			} 
			else {
				ClimberMotorLeft.set(TalonSRXControlMode.PercentOutput,0.);
			}
    	}
    	else {
    		ClimberMotorLeft.set(TalonSRXControlMode.PercentOutput,0.0);
    	}

    	if (joystickLeft_value > .1) {
     		if (currentright < ClimberConstants.ClimberExtendLimitRight || ClimberConstants.ClimberLimitOverride) {
				ClimberMotorRight.set(TalonSRXControlMode.PercentOutput,joystickLeft_value);
			} 
			else {
				ClimberMotorRight.set(TalonSRXControlMode.PercentOutput,0.);
			}
    	}
    	else if (joystickLeft_value < -.1) {
    		if (ClimberRightLowerLimit.get()) {      // returns true until sensor encounters magnet.
				ClimberMotorRight.set(TalonSRXControlMode.PercentOutput,joystickLeft_value);
			} 
			else {
				ClimberMotorRight.set(TalonSRXControlMode.PercentOutput,0.);
			}
    	}
    	else {
    		ClimberMotorRight.set(TalonSRXControlMode.PercentOutput,0.0);
    	}
	}

}