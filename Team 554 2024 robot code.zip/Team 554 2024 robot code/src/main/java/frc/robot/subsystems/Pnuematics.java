package frc.robot.subsystems;

import frc.robot.Robot;

import edu.wpi.first.wpilibj.PneumaticsModuleType;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class Pnuematics extends SubsystemBase {
	
	Compressor compressor;
	private Solenoid Pusher;

    // Put methods for controlling this subsystem
    // here. Call these from Commands.
	
	public Pnuematics(){
		if(Robot.isReal()){
			compressor = new Compressor(0,PneumaticsModuleType.CTREPCM);
			Pusher = new Solenoid(PneumaticsModuleType.CTREPCM,0);
			}
	}

    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }

	public void TurnOnPusherSolenoid() {
		Pusher.set(true);
	}
	public void TurnOffPusherSolenoid() {
		Pusher.set(false);;
	}
  
    public void start(){
    	if(Robot.isReal()){
    		compressor.enableDigital();
    	}
    }
}

