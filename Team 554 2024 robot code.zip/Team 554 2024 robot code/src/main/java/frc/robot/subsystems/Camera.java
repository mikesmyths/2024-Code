/*----------------------------------------------------------------------------*/
/* Copyright (c) 2018 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package frc.robot.subsystems;

import frc.robot.RobotMap;
import frc.robot.Constants.CameraConstants;
import edu.wpi.first.cscore.CvSink;
import edu.wpi.first.cscore.CvSource;
import edu.wpi.first.cscore.UsbCamera;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.cameraserver.CameraServer;
import org.opencv.core.Mat;
import org.opencv.core.Core;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;


/**
 * Add your docs here.
 */
public class Camera extends SubsystemBase {
  // Put methods for controlling this subsystem
  // here. Call these from Commands.
	Thread m_visionThread;

	public void startVisionThread(){
			  m_visionThread = new Thread(() -> {
	  
			  // Get the UsbCamera from CameraServer
			  UsbCamera myCamera = new UsbCamera("cam0", 0);
			  // Set the resolution
			  myCamera.setResolution( CameraConstants.cameraWidth, CameraConstants.cameraHeight);
			  myCamera.setFPS(CameraConstants.cameraFR);
  
			  try (// Get a CvSink. This will capture Mats from the camera
				  CvSink myCvSink = new CvSink("sink1")) {
				  myCvSink.setSource(myCamera);
  
				  // Create the CvSource and MjpegServer and connect them
				  CvSource outputStream =  CameraServer.putVideo("CtrLine", CameraConstants.cameraWidth, CameraConstants.cameraHeight);
							
  
				  // Mats are very memory expensive. Lets reuse this Mat.
				  Mat mat = new Mat();
				  Mat matr = new Mat();
  
				  // This cannot be 'true'. The program will never exit if it is. This
				  // lets the robot stop this thread when restarting robot code or deploying.
				  while (!Thread.interrupted()) {
					  // Tell the CvSink to grab a frame from the camera and put it
					  // in the source mat.  If there is an error notify the output.
					  if (myCvSink.grabFrame(mat) == 0) {
						  // Send the output the error.
						  outputStream.notifyError(myCvSink.getError());
						  // skip the rest of the current iteration
					  continue;
					  }
					  // Put lines on the image
					  Imgproc.line(mat, new Point(CameraConstants.cameraWidth/2,0),
										new Point(CameraConstants.cameraWidth/2,CameraConstants.cameraHeight),
										new Scalar(0,255, 0),2);
					  if (RobotMap.ArmSetpointIndex == 4) {
					      Core.rotate(mat,matr,1);
						  outputStream.putFrame(matr);
						  }
					  else outputStream.putFrame(mat);
					  
				  }
			  }
		  });
		  m_visionThread.setDaemon(true);
		  m_visionThread.start();
	  }


	}
