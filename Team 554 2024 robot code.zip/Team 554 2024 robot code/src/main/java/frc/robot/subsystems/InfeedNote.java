package frc.robot.subsystems;

import com.ctre.phoenix.motorcontrol.TalonSRXControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class InfeedNote extends SubsystemBase {

    public static int 	  InfeedMotorCANaddress = 26;    // ball infeed motor CAN channel

    
    private TalonSRX InfeedMotor;
	
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }
    
    public InfeedNote(){
    	super();
        InfeedMotor = new TalonSRX(InfeedMotorCANaddress);
    }
    
    public void InfeedMotorSetSpeed(double setpoint){
    	InfeedMotor.set(TalonSRXControlMode.PercentOutput,setpoint);
    }


}

