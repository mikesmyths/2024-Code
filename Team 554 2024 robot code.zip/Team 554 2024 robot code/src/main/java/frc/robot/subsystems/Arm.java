package frc.robot.subsystems;

import frc.robot.RobotMap;

import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.TalonSRXControlMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;
import com.ctre.phoenix6.configs.CANcoderConfiguration;
import com.ctre.phoenix6.hardware.CANcoder;
import com.ctre.phoenix6.signals.AbsoluteSensorRangeValue;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

public class Arm extends SubsystemBase {
	//private TalonSRX ArmMotorRedlineLeft;
	//private TalonSRX ArmMotorRedlineRight;
	private TalonSRX ArmMotorDenso;
		private PIDController ArmPIDcontroller;
	private CANcoder ArmEncoder;
	private double absoluteEncoderOffsetDeg = -69.6;  // need to set with correct value;
    
	public Arm() {
		
	super();
	//ArmMotorRedlineLeft = new TalonSRX(22);
	//ArmMotorRedlineRight = new TalonSRX(23);
	ArmMotorDenso = new TalonSRX(21);
	ArmMotorDenso.setNeutralMode(NeutralMode.Coast);
	ArmMotorDenso.setInverted(true);

	ArmPIDcontroller = new PIDController(.01,.0001,0.0);

    ArmEncoder = new CANcoder(22,"canivor1");
    CANcoderConfiguration cc_cfg = new CANcoderConfiguration();
    cc_cfg.MagnetSensor.AbsoluteSensorRange = AbsoluteSensorRangeValue.Signed_PlusMinusHalf;
    cc_cfg.MagnetSensor.MagnetOffset = absoluteEncoderOffsetDeg/360.;  // magnetic offset unit is rotation
    ArmEncoder.getConfigurator().apply(cc_cfg);

}

public void initDefaultCommand() {
    // Set the default command for a subsystem here.
	}

	
	public void UpdateArmPID(double RightJoyStick) {
		double ArmPositionRevs;
		double ArmPositionDegrees;
		double ArmPID_output;
		double DistanceToTargetDegrees;
		double joystickRight_value;
		double mtrcmd;
		double ArmKp;

	if (RobotMap.ArmControlModeManual){
		joystickRight_value = -RightJoyStick ;
		ArmPositionRevs = ArmEncoder.getAbsolutePosition().getValueAsDouble();
		ArmPositionDegrees = ArmPositionRevs * 360.; 
     	SmartDashboard.putNumber("ArmPosition",ArmPositionDegrees);

		//direction =  (joystickRight_value > .2) ? 1:-1; 
    	if (joystickRight_value > .25 && (ArmPositionDegrees < 110.)) mtrcmd = joystickRight_value;
    	else if (joystickRight_value < -.1 )  mtrcmd = -.15;
		else mtrcmd = 0;
     	//SmartDashboard.putNumber("ArmCommand",mtrcmd);
		if (mtrcmd == 0.) {
			ArmMotorDenso.set(TalonSRXControlMode.PercentOutput,0.);
			}
		else {
			ArmMotorDenso.set(TalonSRXControlMode.PercentOutput,mtrcmd);
			}
		}
	else {
		ArmPositionRevs = ArmEncoder.getAbsolutePosition().getValueAsDouble();
		ArmPositionDegrees = ArmPositionRevs * 360.; 
      	SmartDashboard.putNumber("ArmPosition",ArmPositionDegrees);
	
		DistanceToTargetDegrees = (RobotMap.ArmPositionSetpoint - ArmPositionDegrees);
		// if current target is not the final target going to higher points and reversing to the actual target
		if ((RobotMap.ArmFinalPositionIndex != RobotMap.ArmSetpointIndex) &&
		      (DistanceToTargetDegrees < 5.)) {
			RobotMap.ArmSetpointIndex = RobotMap.ArmFinalPositionIndex;
			RobotMap.ShooterSetpointIndex = RobotMap.ArmFinalPositionIndex;
			RobotMap.ArmPositionSetpoint = RobotMap.ArmPositionSetpoints[RobotMap.ArmSetpointIndex];
			RobotMap.ArmInTargetPosition = false;
			DistanceToTargetDegrees = (RobotMap.ArmPositionSetpoint - ArmPositionDegrees); 
  		    }
		ArmKp = (DistanceToTargetDegrees <0.) ? .01 :RobotMap.ArmPositionKPs[RobotMap.ArmSetpointIndex];
        ArmPIDcontroller.setP(ArmKp);
		// if arm is within .5 degrees of position setpoint stop motors and reset pid
		if ((Math.abs(DistanceToTargetDegrees) < .5)) {
			if (RobotMap.ArmInTargetPosition == false) {
				RobotMap.ArmInTargetPosition = true;
				ArmPIDcontroller.reset();
				SmartDashboard.putBoolean("Arm At Target Position", true);
				}
			if ((RobotMap.ShooterRunning == false) && (RobotMap.ShooterSetpointIndex > 1)) {
				RobotMap.ShooterSetPoint = RobotMap.ShooterSetpoints[RobotMap.ShooterSetpointIndex];
				RobotMap.ShooterRunning = true;
				SmartDashboard.putBoolean("Shooter Running",true);
			}
			ArmPIDcontroller.reset();
			ArmMotorDenso.set(TalonSRXControlMode.PercentOutput,0.);
		    }
		else {
			if (RobotMap.ArmInTargetPosition) {
				ArmPIDcontroller.reset();
				}
			ArmPID_output = ArmPIDcontroller.calculate(ArmPositionDegrees,RobotMap.ArmPositionSetpoint);
			  if ((ArmPID_output < 0.) && (ArmPID_output < -1.)) ArmPID_output = -1.;
			  if ((ArmPID_output < 0.) && (ArmPID_output > -.1)) ArmPID_output = -.1;
			  if ((ArmPID_output > 0.) && (ArmPID_output > 1.)) ArmPID_output = 1.;
			  if ((ArmPID_output > 0.) && (ArmPID_output < .1)) ArmPID_output = .1;
			  if ((ArmPositionDegrees < 0.) && ArmPID_output < 0.) ArmPID_output = 0.;  // hard limit down
			  if ((ArmPositionDegrees > 160.) && (ArmPID_output > 0.)) ArmPID_output = 0.;  // hard limit up
			ArmMotorDenso.set(TalonSRXControlMode.PercentOutput,ArmPID_output);
			//SmartDashboard.putNumber("ArmCommand",ArmPID_output);
			}
		}
	}

	public void setStartupArmPosition() {
		double armPosition;
		int i;
		int currentArmPositionindex;
		boolean notfound;

		armPosition = ArmEncoder.getAbsolutePosition().getValueAsDouble() * 360.;
		notfound = true;
		currentArmPositionindex = 0;
		// lookup what positon the arm is in based on current location
		for (i=0; i<5; i++) {
			if ((Math.abs(RobotMap.ArmPositionSetpoints[i]-armPosition) < 5.) && notfound) {
				currentArmPositionindex = i;
				notfound = false;
			}
		RobotMap.ShooterSetpointIndex = currentArmPositionindex;
		RobotMap.ArmPositionSetpoint = armPosition;
		SmartDashboard.putString("Target Position", RobotMap.PostionTargetLabels[currentArmPositionindex]);

		}
	}
}

