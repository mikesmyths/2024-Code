package frc.robot.subsystems;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import com.revrobotics.CANSparkMax;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.SparkPIDController;
import com.revrobotics.SparkRelativeEncoder;
import com.revrobotics.CANSparkBase.IdleMode;
import com.revrobotics.CANSparkLowLevel.MotorType;


public class Shooter extends SubsystemBase {

	// Create empty variables for reassignment
  private final CANSparkMax UpperShooterMotor;
  private final CANSparkMax LowerShooterMotor;

  private final RelativeEncoder UpperShooterEncoder;
  private final RelativeEncoder LowerShooterEncoder;

  //private final PIDController drivingPidController;
  private final SparkPIDController SparkMaxUpperShooterPIDController;
  private final SparkPIDController SparkMaxLowerShooterPIDController;

  public static final double kShooterEncoderRPS = 1.;

  private DigitalInput NoteDetector;
  
	public Shooter() {
		super();
		
    NoteDetector = new DigitalInput(0);

    // Create drive and turning motor
    UpperShooterMotor = new CANSparkMax(27, MotorType.kBrushless);
    LowerShooterMotor = new CANSparkMax(28, MotorType.kBrushless);

    // Set reverse state of drive and turning motor
    UpperShooterMotor.setInverted(true);
    LowerShooterMotor.setInverted(true);

    // Set drive and turning motor encoder values
    UpperShooterEncoder = UpperShooterMotor.getEncoder(SparkRelativeEncoder.Type.kHallSensor,42);
    LowerShooterEncoder = LowerShooterMotor.getEncoder(SparkRelativeEncoder.Type.kHallSensor,42);

    // Change encoder conversion factors
    UpperShooterEncoder.setVelocityConversionFactor(kShooterEncoderRPS);
    LowerShooterEncoder.setVelocityConversionFactor(kShooterEncoderRPS);

    // Create PID controller for Upper Shooter on Sparkmax
    SparkMaxUpperShooterPIDController  = UpperShooterMotor.getPIDController();
    // PID coefficients
    SparkMaxUpperShooterPIDController.setP(.0000);
    SparkMaxUpperShooterPIDController.setI(.0000);
    SparkMaxUpperShooterPIDController.setD(0.);
    SparkMaxUpperShooterPIDController.setIZone(0.);
    SparkMaxUpperShooterPIDController.setFF(.000195);
    SparkMaxUpperShooterPIDController.setOutputRange(-1., 1.);
   
    // Create PID controller for Lower Shooter on Sparkmax
    SparkMaxLowerShooterPIDController  = LowerShooterMotor.getPIDController();
    // PID coefficients
    SparkMaxLowerShooterPIDController.setP(.0000);
    SparkMaxLowerShooterPIDController.setI(.0000001);
    SparkMaxLowerShooterPIDController.setD(0.);
    SparkMaxLowerShooterPIDController.setIZone(0.);
    SparkMaxLowerShooterPIDController.setFF(.00018);
    SparkMaxLowerShooterPIDController.setOutputRange(-1., 1.);
    UpperShooterMotor.setIdleMode(IdleMode.kCoast);
    LowerShooterMotor.setIdleMode(IdleMode.kCoast);

    UpperShooterMotor.setSmartCurrentLimit(40);
    LowerShooterMotor.setSmartCurrentLimit(40);
	}

	public void UpdateShooter(double setpoint) {
		double speed = setpoint; // convert rpm to rps
		SparkMaxUpperShooterPIDController.setReference(speed, CANSparkMax.ControlType.kVelocity);
		SparkMaxLowerShooterPIDController.setReference(speed, CANSparkMax.ControlType.kVelocity);
		//this.UpdateDriverStation();
	}


  public boolean NoteDectected() {
       return NoteDetector.get();
  }

	public void initDefaultCommand() {
        //setDefaultCommand(new MySpecialCommand());
    }

    public void UpdateDriverStation() {
		//SmartDashboard.putNumber("Upper Speed ",UpperShooterEncoder.getVelocity());
		//SmartDashboard.putNumber("Lower Speed ",LowerShooterEncoder.getVelocity());
	}
}

