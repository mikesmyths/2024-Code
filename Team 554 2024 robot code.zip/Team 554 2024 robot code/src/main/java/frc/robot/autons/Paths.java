package frc.robot.autons;

import com.pathplanner.lib.path.PathPlannerPath;

public class Paths {
    public static PathPlannerPath path01a = PathPlannerPath.fromPathFile("path01a");
    public static PathPlannerPath path01b = PathPlannerPath.fromPathFile("path01b");
    public static PathPlannerPath path01c = PathPlannerPath.fromPathFile("path01c");
    public static PathPlannerPath path01d = PathPlannerPath.fromPathFile("path01d");
    public static PathPlannerPath path01e = PathPlannerPath.fromPathFile("path01e");
    public static PathPlannerPath path01f = PathPlannerPath.fromPathFile("path01f");
    }