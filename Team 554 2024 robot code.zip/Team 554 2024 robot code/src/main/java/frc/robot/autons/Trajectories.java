package frc.robot.autons;

import com.pathplanner.lib.path.PathPlannerTrajectory;
import edu.wpi.first.math.geometry.Rotation2d;
import frc.robot.Robot;

public class Trajectories {
    public static PathPlannerTrajectory path01aTrajectory() {
        return new PathPlannerTrajectory(Paths.path01a, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }

    public static PathPlannerTrajectory path01bTrajectory() {
        return new PathPlannerTrajectory(Paths.path01b, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }

    public static PathPlannerTrajectory path01cTrajectory() {
        return new PathPlannerTrajectory(Paths.path01c, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }

    public static PathPlannerTrajectory path01dTrajectory() {
        return new PathPlannerTrajectory(Paths.path01d, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }

    public static PathPlannerTrajectory path01eTrajectory() {
        return new PathPlannerTrajectory(Paths.path01e, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }

    public static PathPlannerTrajectory path01fTrajectory() {
        return new PathPlannerTrajectory(Paths.path01f, Robot.swerveSubsystem.getSpeeds(),
                Rotation2d.fromDegrees(Robot.swerveSubsystem.getHeading()));
    }
}