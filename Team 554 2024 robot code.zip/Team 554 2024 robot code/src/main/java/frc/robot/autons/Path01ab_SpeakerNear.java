package frc.robot.autons;

import edu.wpi.first.wpilibj2.command.ParallelCommandGroup;
import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import edu.wpi.first.wpilibj2.command.WaitCommand;
import frc.robot.RobotMap;
import frc.robot.commands.PickupStartAuto;
import frc.robot.commands.SetTargetPosition;
import frc.robot.commands.ShooterStartAuto;

public class Path01ab_SpeakerNear extends Auton {

    public Path01ab_SpeakerNear() {
 
        this.setInitialPose(Trajectories.path01aTrajectory());
        super.addCommands(
            new SetTargetPosition(RobotMap.AutoSpeakerNear_Index),
            new WaitCommand(.5),
            new ShooterStartAuto(),
            new ParallelCommandGroup(
                followPathCommand(Paths.path01a),
                new SequentialCommandGroup(
                    new WaitCommand(.25),
                    new PickupStartAuto()
                )
            ),
            new ParallelCommandGroup(
                followPathCommand(Paths.path01b),
                new SequentialCommandGroup(
                    new WaitCommand(.1),
                    new SetTargetPosition(RobotMap.AutoSpeakerNear_Index)
                )         
            ),
            new ShooterStartAuto()
        );
    }
}