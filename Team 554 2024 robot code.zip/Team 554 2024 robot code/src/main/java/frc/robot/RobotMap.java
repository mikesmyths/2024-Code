package frc.robot;


public class RobotMap {


		// shooter setpoints in rpm positive=shoot  negative=pickup
		// arm setpoint in degrees 0 = arm horizontal from pivot to front,
		//       negative towards floor (down), postive towards top (up)

		public static int     ShooterOff_Index = 0;
		public static int     Infeed_Index = 0;
		public static int     SpeakerClose_Index = 2;
		public static int     SpeakerFar_Index = 3;
		public static int     Amp_Index = 4;
		public static int     AutoSpeakerNear_Index = 5;
		public static int     AutoSpeakerNearSetup_Index = 6;
		public static int     DeliverNote_Index = 7;

		public static double  ShooterOff_SetPoint = 0.;
		public static double  Infeed_ShooterSetpoint = -1500; //1500
		public static double  SpeakerClose_ShooterSetpoint =3200;  //3200
		public static double  SpeakerFar_ShooterSetpoint  = 3750;  //3750
		public static double  Amp_ShooterSetpoint = 1600;//1600
		public static double  AutoSpeakerNear_ShooterSetpoint = 3200;  //3200
		public static double  AutoSpeakerNearSetup_ShooterSetpoint = 0.;
		public static double  DeliverNote_ShooterSetpoint = 4000;

		public static double[]  ShooterSetpoints = {ShooterOff_SetPoint,
												    Infeed_ShooterSetpoint,
											  	    SpeakerClose_ShooterSetpoint,
											 	    SpeakerFar_ShooterSetpoint,
											  	    Amp_ShooterSetpoint,
											  	    AutoSpeakerNear_ShooterSetpoint,
												    AutoSpeakerNearSetup_ShooterSetpoint,
												    DeliverNote_ShooterSetpoint};

		public static double  Infeed_ArmPosition = -1.;
		public static double  SpeakerClose_ArmSetpoint = 98.;
		public static double  SpeakerFar_ArmSetpoint = 78.;
		public static double  Amp_ArmSetpoint = 158.; 
		public static double  AutoSpeakerNear_ArmSetpoint = 157.; //160
		public static double  AutoSpeakerNearSetup_ArmSetpoint = 140.;
		public static double  DeliverNote_ArmSetpoint = 88.;

		public static double[]  ArmPositionSetpoints = { Infeed_ArmPosition,
												Infeed_ArmPosition,
											  	SpeakerClose_ArmSetpoint,
											 	SpeakerFar_ArmSetpoint,
											  	Amp_ArmSetpoint,
											  	AutoSpeakerNear_ArmSetpoint,
											    AutoSpeakerNearSetup_ArmSetpoint,
											    DeliverNote_ArmSetpoint};

		public static double[]  ArmPositionKPs = { .015,  //infeed
												   .015,  //infeed
											  	   .07,	  //speaker close
											 	   .11,	  //speaker far
											  	   .01,	  //amp
											  	   .01,  //autonomous01
											       .014, //autonomous01 setup
										 		  .08}; // Delivernote

		public static String[] PostionTargetLabels = { "Infeed",
													   "Infeed",
													   "Speaker Close",
													   "Speaker Far",
													   "AMP",
													   "Autonomous",
												       "Autonomous Setup",
													   "Deliver Note"};

		public static int  	  ShooterSetpointIndex = 0;
		public static double  ShooterSetPoint = ShooterOff_SetPoint;
		public static int     ArmSetpointIndex = 0;
		public static int     ArmFinalPositionIndex = 0;
		public static double  ArmPositionSetpoint = ArmPositionSetpoints[0];
		public static boolean ArmControlModeManual = false;

		public static boolean ShooterRunning = false;
		public static double  ShooterActualRPM = 0.;
		public static boolean InfeedRunning = false; 
		public static double  InfeedMotorSpeed = .4;


		public static double  Driver_Joystick_Multiplier = 1.;
		public static double  Driver_Joystick_MultiplierNormal = 1.;
		public static double  Driver_Joystick_MultiplierSlow = .3;
		public static double  Driver_Joystick_MultiplierFast = 4.5/3.5;

		public static int	  currentLEDdisplay = 0;
		public static boolean ArmInTargetPosition = false;
		public static boolean allianceIsRed;
		public static double  AutoGyroOffsetValue = 0.;
		public static boolean inTeleop = false;
		public static double  driveMoveAtAngleStraf = 0.;
		public static double  driveMoveAtAngleForward = 0.;
		public static double  driveMoveAtAngleRotation = 0.;

		public static boolean ResetGyroFlag = false;


	
}